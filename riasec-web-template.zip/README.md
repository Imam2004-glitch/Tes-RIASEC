# Tes Minat dan Bakat RIASEC

Project ini adalah web apps berbasis Next.js + Firebase untuk tes minat karir menggunakan model RIASEC.