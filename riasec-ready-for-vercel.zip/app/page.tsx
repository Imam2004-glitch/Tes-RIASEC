export default function HomePage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Tes Minat dan Bakat RIASEC</h1>
      <p>Ketahui karirmu untuk merencanakan masa depanmu</p>
      <a href="/form-identitas">Mulai</a>
    </main>
  )
}
